<?php

	$name=$_GET["name"];
	$email=$_GET["email"];
	$uname=$_GET["userName"];
	$pass=$_GET["password"];
	$cpass=$_GET["confirmPassword"];
	$gender=$_GET["gender"];
	$dob=$_GET["d"];
	$radio;
	
	if($gender=="male"){
		$radio="Male";
	}
	elseif($gender=="female"){
		$radio="Female";
	}
	else{
		$radio="Other";
	}
	
	if($name == "" || $email == ""|| $uname == "" || $pass==""|| $cpass == "" || $gender=="" || $dob==""){
		
		echo "All fields must be filled up!";
	}
	else{
		if($pass != $cpass){
			echo "Passwords don't match!";
		}
		else{
			
			$servername ="localhost";
			$username 	="root";
			$password 	="";
			$dbname 	="webtech";
			
			$conn = mysqli_connect($servername, $username, $password, $dbname);
			
			if(!$conn){
				die("Connection Error!".mysqli_connect_error());
			}
			
				 $sql = "INSERT INTO reg(name,email,user name,password,gender,date of birth) VALUES($name,$email,$uname,$pass,$radio,$dob)";
				//$sql = "insert into user values($name,$email,$uname,$pass,$radio,$dob)";
			
			if(mysqli_query($conn, $sql)){
				echo "<br/> Data Inserted!";
			}else{
				echo "<br/> SQL Error".mysqli_error($conn);
			}

			mysqli_close($conn);
			
			header('Location: login.html');
		}
	}




?>